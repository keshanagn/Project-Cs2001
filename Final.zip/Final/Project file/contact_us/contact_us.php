
<?php

include '../connection.php';
include '../function.php';

// if (!isLoggedIn()) {
//     $_SESSION['msg'] = "You must log in first";
//     header('location: ../Sign In/login.php');
// }

?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Customer Default</title>
    <link rel="stylesheet" href="./contact_us.css">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <script src="./cus_my_acc.js"></script>
    <title>Home Page</title>
</head>
<body>


<!--================================Header====================================-->



    <header class="head-1">
        <div id="sec-1">
            <a href="#">
                <img src="./mushroom.png" style="width: 50px; height: 50px;" alt = "titleimage">
                <p style="font-family: Arial, Helvetica, sans-serif; font-size: 40px; color: rgb(106, 98, 98);">CRM</p>
            </a>
        </div>
        <div id="sec-2">
            <ul id="ul-1">
                <li><a href="../Home/Home.php">Home</a></li>
                <li><a href="../help/help.php">Help</a></li>
                <li><a href="../Sign In/login.php">Sign In</a></li>
                <li><a href="../Sign up/register.php">Sign Up</a></li>
                
            </ul>
        </div>
    </header>

<!--=================================Sign-Out==================================-->


    <section class="sign-out">   
        <!-- <p><a href="customer_1.php?logout='1'">Sign Out</a></p>   -->
        <!-- <?php if (isset($_SESSION['user'])) : ?>
            <p><a href="customer_1.php?logout='1'">Sign Out</a></p>
            <p id="user">user: <strong><?php echo $_SESSION['user']['username']; ?></strong></p>
            
            

        <?php endif ?> -->
    </section>

<!--=================================Body Part==================================-->


<div id = "contact">
    <h1 id = "contact1">Contact us</h1>
    <p id = "contact2">Email</p>
    <p id = "contact3"><a href = "mailto:uoc@gmail.com" class = "contact2">uoc@gmail.com</p>
</div> 


<!--==================================Footer====================================-->



    <section class="footer">
        <div class="item"><a href="#">Terms and Conditions</a></div>
        <div class="item"><a href="#">Help</a></div>
        <div class="item"><a href="#">CS2001</a></div>


    </section>



</body>



</html>