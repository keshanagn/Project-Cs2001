<?php

    include './cus_my_acc/cus_details_my_acc.php';
    include '../connection.php';
    include '../function.php';

    if (!isLoggedIn()) {
        $_SESSION['msg'] = "You must log in first";
        header('location: ../Sign In/login.php');
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cus My Acc</title>
    <link rel="stylesheet" href="./cus_my_acc_1.css">
</head>
<body>
    <div id="section-1">
        <div class="circle">
            <img src="./cus_my_acc/profile_pic_2.png" alt="default profile picture">
        </div>
        
    </div>
    <div id="section-2">
    
        
        <?php if (isset($_SESSION['user'])) : ?>
            <table id="grid-container">
                
                <tr><td>Name</td></tr>
                <tr id="details"><td id="cells"><?php echo $_SESSION['user']['username']; ?></td></tr>
                <tr><td>Email</td></tr>
                <tr id="details"><td id="cells"><?php echo $_SESSION['user']['email']; ?></td></tr>
                <tr><td>User Type</td></tr>
                <tr id="details"><td id="cells"><?php echo $_SESSION['user']['user_type']; ?></td></tr>
                
                
            </table>
            

        <?php endif ?>
    
    </div>
</body>
</html>