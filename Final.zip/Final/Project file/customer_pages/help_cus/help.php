
<?php

include '../../connection.php';
include '../../function.php';

if (!isLoggedIn()) {
    $_SESSION['msg'] = "You must log in first";
    header('location: ../../Sign In/login.php');
}

?> 

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Customer Default</title>
    <link rel="stylesheet" href="./help.css">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <script src="./cus_my_acc.js"></script>
    <title>Help Page</title>
</head>
<body>


<!--================================Header====================================-->



    <header class="head-1">
        <div id="sec-1">
            <a href="#">
                <img src="./mushroom.png" style="width: 50px; height: 50px;" alt = "titleimage">
                <p style="font-family: Arial, Helvetica, sans-serif; font-size: 40px; color: rgb(106, 98, 98);">CRM</p>
            </a>
        </div>
        <div id="sec-2">
            <ul id="ul-1">
                <li><a href="../home_cus/Home_cus.php">Home</a></li>
                <li><a href="../customer_1.php">Customer</a></li>
                <li><a href="../cus_contact_us/contact_us.php">Contact Us</a></li>
                <!-- <li><a href="#">Share</a></li> -->
                
            </ul>
        </div>
    </header>

<!--=================================Sign-Out==================================-->


    <section class="sign-out">   
        <!-- <p><a href="customer_1.php?logout='1'">Sign Out</a></p>   -->
        <?php if (isset($_SESSION['user'])) : ?>
            <p><a href="help.php?logout='1'">Sign Out</a></p>
            <p id="user">user: <strong><?php echo $_SESSION['user']['username']; ?></strong></p>
            
            

        <?php endif ?>
    </section>

<!--=================================Body Part==================================-->


<div style="margin-left:100px;">
    <h1 style = "margin-left:500px;
                 color:black;font-size:50px;">Help</h1>
    <p style = "margin-left:430px;
                 color:black;font-size:40px;">Customer Support</p>
    <img src="1.png" alt="customer support" width= 1100 height=500 style="border:2px solid black;"><br>
    <img src="4.png" alt="customer support" width= 1100 height=500 style="border:2px solid black;"><br>
    <img src="2.png" alt="customer support"width = 1100 height = 500 style="border:2px solid black;"><br><br>
    <p style = "margin-left:430px;
                 color:black; font-size:40px;">Admin Support</p>
    <img src="4.png" alt="admin support" width =1100 height = 500 style="border:2px solid black;"><br>
    <img src="3.png" alt="customer support" width= 1100 height=500 style="border:2px solid black;"><br>
</div>


<!--==================================Footer====================================-->



    <section class="footer">
        <div class="item"><a href="#">Terms and Conditions</a></div>
        <div class="item"><a href="#">Help</a></div>
        <div class="item"><a href="#">CS2001</a></div>


    </section>



</body>



</html>