<?php

include '../connection.php';

if(isset($_GET['deleterec'])){
    $row=$_GET['deleterec'];



    $sql="delete from cus_details where No=$row";
    $result=mysqli_query($conn,$sql);
    if($result){
        // echo "Deleted Successfully";
        header("location:cus_details.php");
    }else{

    };
};
    
?>