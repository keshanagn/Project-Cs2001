

<?php

include '../connection.php';
include '../function.php';

if (!isLoggedIn()) {
    $_SESSION['msg'] = "You must log in first";
    header('location: ../Sign In/login.php');
}

?>


<!DOCTYPE html>
<head>
    <link rel="stylesheet" href="./cus_mycontacts.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script src="./cus_my_contacts.js"></script>
</head>
<body>


<!--==============================Nav Bar===================================-->


    <div class="nav-bar">
        <div id="searchbox">
            
        </div>
        <div id="list">
            <ul>
                <li onclick="openform()">Add</li>
                
            </ul>
        </div>

    </div>

<!--=================================Grid Form================================-->


    <div class="form">
        <iframe id="cus_table" src="./cus_details.php"></iframe>
        


    </div>
</body>