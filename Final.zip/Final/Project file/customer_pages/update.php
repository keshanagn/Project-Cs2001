<?php

include '../connection.php';



$id=$_GET['updaterec'];

$sql="select * from cus_details where No=$id";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result);
$name=$row['Name'];
$tele=$row['Telephone'];
$email=$row['Email'];



if (isset($_POST['submit'])) {
    
    $name = $_POST['name'];
    $tele = $_POST['tele'];
    $email = $_POST['email'];

    $sql = "update cus_details set No=$id, Name='$name', Telephone='$tele', Email='$email' where No='$id'";

    $result = mysqli_query($conn,$sql);
    if($result){
        header('location:cus_details.php');
    }

    
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./form.css">
    <title>Form</title>
</head>
<body>
    <form id="form_pop" method="post" action="">
        <div id="heading">Enter Details</div>
        <div class="grid-container">
            <div class="grid-item">Name</div>
            <div class="grid-item"><input type="text" placeholder="Enter the Name" name="name" value=<?php echo $name?> required></div>
            <div class="grid-item">Telephone</div>
            <div class="grid-item"><input type="text" placeholder="Enter the Telephone No" name="tele" value=<?php echo $tele?> required></div>
            <div class="grid-item">Email</div>
            <div class="grid-item"><input type="email" placeholder="Enter Email" name="email" value=<?php echo $email?> required></div>
            <div class="grid-item-btn"><button type="submit" value="Submit" name="submit">Update</div>
        </div>
    </form>
</body>
</html>