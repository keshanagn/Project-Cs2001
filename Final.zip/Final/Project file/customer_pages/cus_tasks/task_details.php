<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./task_details.css">
</head>
<body>
    <table id="cus_tasks">`             <!--table name-->
        <thead id="tb_head">
            <tr>
                <!-- <th id="no">No</th> -->
                <th id="task">Task</th>
                <!-- <th id="tel">Telephone</th>
                <th id="email">Email</th> -->
                <th id="op">Operations</th>
            </tr>
        </thead>
        <tbody>
            <?php
            
            include '../../connection.php';
            $sql='select * from tasks';
            $result=mysqli_query($conn,$sql);
            if($result){
                while($row=mysqli_fetch_assoc($result)){
                    $no=$row['No'];
                    $task=$row['Task'];
                    // $tel=$row['Telephone'];
                    // $email=$row['Email'];
                    echo'<tr>
                    
                    <td>'.$task.'</td>
                    
                    <td>
                        <button class="ud-btn"><a href="update.php?updaterec='.$no.'">Update</a></button>
                        <button class="ud-btn"><a href="delete.php?deleterec='.$no.'">Delete</a></button>
                    </td>

                    </tr>';
                                  
                }
            }





            ?>
        </tbody>
    </table>
</body>
</html>


<!-- 
<td>'.$tel.'</td>
<td>'.$email.'</td> -->

<!-- <td>'.$no.'</td> -->
