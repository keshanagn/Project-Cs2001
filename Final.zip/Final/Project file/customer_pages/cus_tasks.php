<!DOCTYPE html>
<head>
    <link rel="stylesheet" href="./cus_tasks.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script src="./cus_tasks/cus_tasks.js"></script>
</head>
<body>
    <div class="nav-bar">
        <div id="searchbox">
            
        </div>
        <div id="list">
            <ul>
                <li onclick="openform()">Add</li>
                
            </ul>
        </div>

    </div>
    <div class="form">
        <iframe id="task_table" src="./cus_tasks/task_details.php"></iframe>
        
    </div>

</body>