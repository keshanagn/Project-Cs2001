<?php

include './cus_feedback/comment.php';


?>

<!DOCTYPE html>
<head>
    <link rel="stylesheet" href="./cus_feedback.css">

</head>
<body>
    <form action="./cus_feedback/comment.php" method="POST" id="feedback">
        <div id="heading">Feedback Form</div>
        <div class="grid-container">
            <div class="grid_item">Subject</div>
            <div class="grid_item" ><input type="text" name ="sub" required></div>
            <div>
                <select class="grid_item" name="opt" placeholder="choose">
                    <option value="complaint">complaint</option>
                    <option value="feedback">feedback</option>
                </select>
            </div>

        
            <div class="grid_item">Comments</div>
            <div class="grid_item"><textarea name="complaints" form="feedback" row="10" column="50" placeholder="Enter your Comments Here..." required></textarea></div>
            <div class="grid_item_1"><input type="submit" value="Submit"></div>

        </div>
    </form>

</body>

</html>
    

