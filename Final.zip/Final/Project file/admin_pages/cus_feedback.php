



<?php

include '../connection.php';
include '../function.php';

if (!isLoggedIn()) {
    $_SESSION['msg'] = "You must log in first";
    header('location: ../Sign In/login.php');
}

?>


<!DOCTYPE html>
<head>
    <link rel="stylesheet" href="./cus_mycontacts.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script src="./cus_my_contacts.js"></script>
</head>
<body>


<!--==============================Nav Bar===================================-->


    <div class="nav-bar">
        <div id="searchbox">
            <!-- <ul>
                <li><input type="search" placeholder="Search Contacts..."></li>
                <li><i class='bx bx-search'>Search</i></li>
            </ul> -->
        </div>
        <div id="list">
            <ul>
                <!-- <li onclick="openform()">Add</li> -->
                <!-- <li>Delete</li>
                <li>Update</li> -->
            </ul>
        </div>

    </div>

<!--=================================Grid Form================================-->


    <div class="form">
        <iframe id="cus_table" src="./cus_feedback/cus_feedback_details.php"></iframe>
        

<!-- 
        <form>
            <div class="grid-container">
                <div class="grid-item-1"></div>
                <div class="grid-item-1">Name</div>
                <div class="grid-item-1">Business</div>
                <div class="grid-item-1">Telephone</div>
                <div class="grid-item-1">Address</div>
                <div class="grid-item">1</div>
                <div class="grid-item"></div>
            </div>
        </form> -->
    </div>
</body>