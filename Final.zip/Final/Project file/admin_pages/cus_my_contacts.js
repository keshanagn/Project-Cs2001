
function openform(){
    window.parent.document.getElementById("frame_1").src="./form.php";

}