<!-- connection -->

<?php

$servername="localhost";
$username= "root";
$password= "";
$dbname= "customer";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("". $conn->connect_error).$conn->connect_error;
}//else{
// //     echo "Connection successful";
// // }


?>