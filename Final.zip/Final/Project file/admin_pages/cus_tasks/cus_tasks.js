
function openform(){
    window.parent.document.getElementById("frame_1").src="./cus_tasks/add_form.php";

}