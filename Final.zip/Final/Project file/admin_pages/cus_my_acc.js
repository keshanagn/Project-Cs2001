var myiframe=document.getElementById("frame_1");
myiframe.src="./cus_my_acc.html";

function chnge_frame_1(){
    document.getElementById("frame_1").src="./cus_my_acc_1.php";
}

function chnge_frame_2(){
    document.getElementById("frame_1").src="./cus_feedback.php";
}

function chnge_frame_3(){
    document.getElementById("frame_1").src="./cus_mycontacts.php";
}

function chnge_frame_4(){
    document.getElementById("frame_1").src="./cus_tasks.php";
}

