
<!--================================ Not needed================================ -->
<!--================================ Not needed================================ -->
<!--================================ Not needed================================ -->
<!--================================ Not needed================================ -->
<!--================================ Not needed================================ -->
<!--================================ Not needed================================ -->


<?php


// session_start(); // Start the session

// if (!isset($_SESSION['email'])) {
//     // Redirect to the sign-in page if the user is not logged in
//     header("Location: ../SignIn/signin.php"); // Change to your sign-in page
//     exit;
// }
// include '../../function.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $user_id=$_SESSION['user']['username'];
    $email = $_SESSION['user']['email'];
    $user_type=$_SESSION['user']['user_type'];
    // $subject = $_POST['sub']; // Updated input name
    // $type = $_POST['opt']; // Updated select name
    // $complaints = $_POST['complaints'];

    $servername = "localhost"; // Change to your database server hostname
    $db_username = "root"; // Change to your database username
    $db_password = ""; // Change to your database password
    $db_name = "customer"; // Change to your database name

    $conn = new mysqli($servername, $db_username, $db_password, $db_name);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

}



    

    // Insert the form data into the database
    //Moved to cus_my_acc_1.php
    // $sql = "SELECT FROM users (user_id,email, sub, opt, comment) WHERE username='$user_id'";
    // $result=mysqli_query($conn,$sql);
    // $row=mysqli_fetch_array($result);
    // $name=$row['username'];
    // $tele=$row['email'];
    // $email=$row['user_type'];
    // echo'
    // <tr>User Name</tr>
    // <tr>'.$user_id.'</tr>
    // <tr>Email</tr>
    // <tr>'.$email.'</tr>
    // <tr>user_type</tr>
    // <tr>'.$user_type.'
    // </tr>
    
    
    //     <button class="ud-btn"><a href="update.php?updaterec='.$user_id.'">Update</a></button>
        
    // </tr>';
    




//     if ($conn->query($sql) === TRUE) {
//         // Comment saved successfully
//         // echo "Succefuly entered your complaint";// Redirect to a success page

//         header ('location: ../cus_feedback.php');
//         exit;
//     } else {
//         // Error in saving the comment
//         echo "Error: " . $sql . "<br>" . $conn->error;
//     }

//     $conn->close();
// }

?>



<!-- <button class="ud-btn"><a href="delete.php?deleterec='.$no.'">Delete</a></button> -->