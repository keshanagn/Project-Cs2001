<?php

    include './cus_my_acc/cus_details_my_acc.php';
    include '../connection.php';
    include '../function.php';

    if (!isLoggedIn()) {
        $_SESSION['msg'] = "You must log in first";
        header('location: ../Sign In/login.php');
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cus My Acc</title>
    <link rel="stylesheet" href="./cus_my_acc_1.css">
</head>
<body>
    <div id="section-1">
        <div class="circle">
            <img src="./cus_my_acc/profile_pic_2.png" alt="default profile picture">
        </div>
        
    </div>
    <div id="section-2">
    
        
        <?php if (isset($_SESSION['user'])) : ?>
            <table id="grid-container">
                
                <tr><td>Name</td></tr>
                <tr id="details"><td id="cells"><?php echo $_SESSION['user']['username']; ?></td></tr>
                <tr><td>Email</td></tr>
                <tr id="details"><td id="cells"><?php echo $_SESSION['user']['email']; ?></td></tr>
                <tr><td>User Type</td></tr>
                <tr id="details"><td id="cells"><?php echo $_SESSION['user']['user_type']; ?></td></tr>
                <!-- <tr id="submit"><td><button id="update" type="submit" name="update">Update</button></td></tr> -->
                
            </table>
            

        <?php endif ?>
    
        
            
            
            
                                  
                
            





            
            <!-- <tr>User Name</tr>
            <tr>$user_id</tr>
            <tr>Email</tr>
            <tr>'.$email.'</tr>
            <tr>user_type</tr>
            <tr>'.$user_type.'
            </tr>
                <button class="ud-btn"><a href="update.php?updaterec='.$user_id.'">Update</a></button>
                    
            </tr>
            
        
            

                // $sql = "SELECT FROM users (user_id,email, sub, opt, comment) WHERE username='$user_id'";
                // $result=mysqli_query($conn,$sql);
                // $row=mysqli_fetch_array($result);
                // $name=$row['username'];
                // $tele=$row['email'];
                // $email=$row['user_type'];

                echo '
                <tr>User Name</tr>
                <tr>'.$user_id.'</tr>
                <tr>Email</tr>
                <tr>'.$email.'</tr>
                <tr>user_type</tr>
                <tr>'.$user_type.'
                </tr>
                
                
                    <button class="ud-btn"><a href="update.php?updaterec='.$user_id.'">Update</a></button>
                    
                </tr>';

            
        <table> -->






        
        
    </div>
</body>
</html>






<!-- <tr>Name</tr>
            <tr></tr>
            <tr>Email</tr>
            <tr></tr>
            <tr>User Type</tr>
            <tr></tr>
            <tr>
                <button class="ud-btn">
                    <a href="update.php?updaterec='.$no.'">Update</a>
                </button>
            </tr> -->