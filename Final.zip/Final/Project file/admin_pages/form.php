<!-- ==========================add form=================================== -->




<?php

include '../connection.php';



if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    // $tele = $_POST['tele'];
    $email = $_POST['email'];

    $sql = "INSERT INTO users (username, Email, user_type) VALUES ('$name', '$email', 'user')";

    $result = $conn->query($sql);
    if($result){
        header('location: ./cus_mycontacts.php');
    }

    
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./form.css">
    <title>Form</title>
</head>
<body>
    <form id="form_pop" method="post" action="">
        <div id="heading">Enter Details</div>
        <div class="grid-container">
            <div class="grid-item">Name</div>
            <div class="grid-item"><input type="text" placeholder="Enter the Name" name="name"></div>
            <!-- <div class="grid-item">Telephone</div>
            <div class="grid-item"><input type="text" placeholder="Enter the Telephone No" name="tele"></div> -->
            <div class="grid-item">Email</div>
            <div class="grid-item"><input type="email" placeholder="Enter Email" name="email"></div>
            <div class="grid-item-btn"><button type="submit" value="Submit" name="submit">Submit</div>
        </div>
    </form>
</body>
</html>