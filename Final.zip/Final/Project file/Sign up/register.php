
<?php 
include '../function.php';
include './connection.php';


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="./sign_up.css">
</head>
<body>
    
    
<!--================================Header====================================-->



    <header class="head-1">
        <div id="sec-1">
            <a href="#">
                <img src="./mushroom.png" style="width: 50px; height: 50px;">
                <p style="font-family: Arial, Helvetica, sans-serif; font-size: 40px; color: rgb(106, 98, 98);">CRM</p>
            </a>
        </div>
        <div id="sec-2">
            <ul id="ul-1">
                <li><a href="../Home/Home.php">Home</a></li>
                <li><a href="../help/help.php">Help</a></li>
                <li><a href="../contact_us/contact_us.php">Contact Us</a></li>
                
                <li><a href="../Sign In/login.php">Sign in</a></li>
                
            </ul>
        </div>
    </header>


    <!--=================================Body Part==================================-->


    <section class="middle">



        <div id ="sign_up_form">
            <div id="form_head">Sign Up</div>
            <form method="post" action="register.php">
                <?php echo display_error(); ?>
                <div class="grid-container">
                    <div class="grid-item">Username</div>
                    <div class="grid-item"><input  type="text" name="username" value="<?php echo $username  ?>"></div>
                    <div class="grid-item">Email</div>
                    <div class="grid-item"><input  type="email" name="email" value="<?php echo $email  ?>"></div>
                    <div class="grid-item">Password</div>

                    

                    <div class="grid-item"><input  type="password" name="password_1" value=""></div>
                    <div class="grid-item">Confirm the password</div>
                    <div class="grid-item"><input  type="password" name="password_2" value=""></div>
                    <div class="grid-item-1">
                        <button  name="register_btn" type="submit" value="submit">Sign Up</button> 
                        <p>Already have an Account<a href="../Sign In/login.php">Sign in</a></p>

                    </div>
                    
                </div>

            </form>
            
        </div>




        
        
        <!--Enter the body part code here-->
        <!--Enter the body part code here-->
        <!--Enter the body part code here-->
        <!--Enter the body part code here-->









    </section>


    <!--==================================Footer====================================-->



    <section class="footer">
        <div id="item"><a href="#">Terms and Conditions</a></div>
        <div id="item"><a href="#">Help</a></div>
        <div id="item"><a href="#">CS2001</a></div>


    </section>

</body>
</html>