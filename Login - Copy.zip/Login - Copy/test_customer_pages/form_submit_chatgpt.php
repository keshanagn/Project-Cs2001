<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "customer";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST["submit"])) {
    $name = $_POST['name'];

    $sql = "INSERT INTO test (Name) VALUES ('$name')";
    $result = $conn->query($sql);

    if ($result) {
        echo "Inserted successfully";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form</title>
</head>
<body>
    <form method="post" action="">
        <input type="text" placeholder="Enter Name" name="name">
        <button type="submit" name="submit">Submit</button>
    </form>
</body>
</html>
