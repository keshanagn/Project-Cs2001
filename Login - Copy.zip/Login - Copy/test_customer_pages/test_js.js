
function openform(){
    document.getElementById("myiframe").src="./form.php"
}