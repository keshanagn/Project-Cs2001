<!DOCTYPE html>
<html>
<head>
    <title>External PHP Page</title>
</head>
<body>
    <h1>This is an external PHP page.</h1>
    <p>Content of the PHP page goes here.</p>
</body>
</html>
