<?php
include("includes/dbh.php");
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $sql = "select * from employer where username='" . $username . "' AND password='" . $password . "' ";

    $result = mysqli_query($conn, $sql);

    if ($result) {
        $row = mysqli_fetch_array($result);
        if ($row) {
            if ($row["usertype"] == "user") {
                $_SESSION["username"] = $username;
                header("location:func.php");
            } elseif ($row["usertype"] == "admin") {
                $_SESSION["username"] = $username;
                header("location:admin.php");
            } else {
                header("location:login.php?error=1"); // Redirect with an error parameter.
            }
        } else {
            header("location:login.php?error=1"); // Redirect with an error parameter.
        }
    } else {
        header("location:login.php?error=2"); // Redirect with a different error parameter for database query error.
    }
}
?>

<?php 
    include_once 'header.php'; 
?>

<div class="login-container">
    <form id="login-form" action="login.php" method="post">
        <h2>Login</h2>
        <label for="username">Username</label>
        <input type="text" id="username" placeholder="Email/Username" name="username" required>
        <label for="password">Password</label>
        <input type="password" id="password" name="password" required>
        <input type="checkbox" id="remember-me" name="remember" value="1">
        <label for="remember-me">Remember Me</label>
        <button type="submit">Login</button>
    </form>
    <p>Don't have an account? <a href="sign_red.php">Sign up</a></p>
</div>

<?php 
    include_once 'footer.php'; 
?>