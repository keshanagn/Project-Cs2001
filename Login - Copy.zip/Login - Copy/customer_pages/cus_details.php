<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./cus_details.css">
</head>
<body>
    <table id="cus_details">
        <thead id="tb_head">
            <tr>
                <th id="no">Id</th>
                <th id="name">Name</th>
                <th id="tel">Tel No.</th>
                <th id="email">Email</th>
                <th id="op">Operations</th>
            </tr>
        </thead>
        <tbody>
            <?php
            
            include 'connection.php';
            $sql='select * from cus_details';
            $result=mysqli_query($conn,$sql);
            if($result){
                while($row=mysqli_fetch_assoc($result)){
                    $no=$row['No'];
                    $name=$row['Name'];
                    $tel=$row['Telephone'];
                    $email=$row['Email'];
                    echo'<tr>
                    <td>'.$no.'</td>
                    <td>'.$name.'</td>
                    <td>'.$tel.'</td>
                    <td>'.$email.'</td>
                    <td>
                        <button class="ud-btn"><a href="update.php?updaterec='.$no.'">Update</a></button>
                        <button class="ud-btn"><a href="delete.php?deleterec='.$no.'">Delete</a></button>
                    </td>

                    </tr>';
                                  
                }
            }





            ?>
        </tbody>
    </table>
</body>
</html>