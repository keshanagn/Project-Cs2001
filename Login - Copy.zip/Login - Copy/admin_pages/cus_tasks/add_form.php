

<?php

include "../connection.php";
include '../../function.php';

if (!isLoggedIn()) {
    $_SESSION['msg'] = "You must log in first";
    header('location: ../../Sign In/login.php');
}

if (isset($_POST['submit'])) {
    $task = $_POST['task'];
    // $tele = $_POST['tele'];
    // $email = $_POST['email'];

    $sql = "INSERT INTO tasks (Task) VALUES ('$task')";

    $result = $conn->query($sql);
    if($result){
        header('location:../cus_tasks.php');
    }

    
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./add_form.css">
    <title>Form</title>
</head>
<body>
    <form id="form_pop" method="post" action="">
        <div id="heading">Enter Details</div>
        <div class="grid-container">
            <div class="grid-item">Task</div>
            <div class="grid-item"><input type="text" placeholder="Enter the Task" name="task"></div>
            <!-- <div class="grid-item">Telephone</div>
            <div class="grid-item"><input type="text" placeholder="Enter the Telephone No" name="tele"></div>
            <div class="grid-item">Email</div>
            <div class="grid-item"><input type="email" placeholder="Enter Email" name="email"></div> -->
            <div class="grid-item-btn"><button type="submit" value="Submit" name="submit">Submit</div>
        </div>
    </form>
</body>
</html>