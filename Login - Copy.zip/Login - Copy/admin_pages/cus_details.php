<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./cus_details.css">
</head>
<body>
    <table id="cus_details">
        <thead id="tb_head">
            <tr>
                <th id="name">Username</th>
                <th id="email">Email</th>
                <!-- <th id="tel">Tel No.</th>
                <th id="email">Email</th> -->
                <th id="op">Operations</th>
            </tr>
        </thead>
        <tbody>
            <?php
            
            include 'connection.php';
            $sql='select * from users where user_type="user"';
            $result=mysqli_query($conn,$sql);
            if($result){
                while($row=mysqli_fetch_assoc($result)){
                    $no=$row['id'];
                    $name=$row['username'];
                    // $tel=$row['Telephone'];
                    $email=$row['email'];
                    echo'<tr>
                    <td>'.$name.'</td>
                    <td>'.$email.'</td>
                    
                    <td>
                        
                        <button class="ud-btn"><a href="delete.php?deleterec='.$no.'">Delete</a></button>
                    </td>

                    </tr>';
                                  
                }
            }





            ?>
        </tbody>
    </table>
</body>
</html>



<!-- <td>'.$tel.'</td>
<td>'.$email.'</td> -->

<!-- <button class="ud-btn"><a href="update.php?updaterec='.$no.'">Update</a></button> -->