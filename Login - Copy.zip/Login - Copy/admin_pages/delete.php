<?php

include 'connection.php';

if(isset($_GET['deleterec'])){
    $row=$_GET['deleterec'];



    $sql="delete from users where id=$row";
    $result=mysqli_query($conn,$sql);
    if($result){
        // echo "Deleted Successfully";
        header("location:cus_details.php");
    }else{

    };
};
    







?>