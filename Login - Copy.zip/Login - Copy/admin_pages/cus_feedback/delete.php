<?php

include '../../connection.php';

if(isset($_GET['deleterec'])){
    $row=$_GET['deleterec'];



    $sql="delete from feedback where No=$row";
    $result=mysqli_query($conn,$sql);
    if($result){
        // echo "Deleted Successfully";
        header("location:./cus_feedback_details.php");
    }else{

    };
};
    







?>