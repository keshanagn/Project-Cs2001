
<?php

include '../connection.php';
include '../function.php';

if (!isLoggedIn()) {
    $_SESSION['msg'] = "You must log in first";
    header('location: ../Sign In/login.php');
}

?>

<!DOCTYPE html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Customer Default</title>
    <link rel="stylesheet" href="./customer-1.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script src="./cus_my_acc.js"></script>
</head>
<body>


<!--================================Header====================================-->



    <header class="head-1">
        <div id="sec-1">
            <a href="#">
                <img src="./mushroom.png" style="width: 50px; height: 50px;">
                <p style="font-family: Arial, Helvetica, sans-serif; font-size: 40px; color: rgb(106, 98, 98);">CRM</p>
            </a>
        </div>
        <div id="sec-2">
            <ul id="ul-1">
                <li><a href="./home_cus/Home_cus.php">Home</a></li>
                <li><a href="#">Help</a></li>
                <li><a href="#">Contact Us</a></li>
                <!-- <li><a href="#">Share</a></li> -->
                
            </ul>
        </div>
    </header>

<!--=================================Sign-Out==================================-->


    <section class="sign-out">   
        <!-- <p><a href="customer_1.php?logout='1'">Sign Out</a></p>   -->
        <?php if (isset($_SESSION['user'])) : ?>
            <p><a href="customer_1.php?logout='1'">Sign Out</a></p>
            <p id="user">user: <strong><?php echo $_SESSION['user']['username']; ?></strong></p>
            
            <!-- <small>
                <p><a href="customer_1.php?logout='1'">Sign Out</a></p> 
            </small> -->

        <?php endif ?>
    </section>

<!--=================================Body Part==================================-->


    <section class="middle">
        <div class="div-1">
            <ul>
                <li onclick="chnge_frame_1()">My Account</li>
                <li onclick="chnge_frame_2()">Feedback</li>
                <li onclick="chnge_frame_3()">Customers</li>
                <li onclick="chnge_frame_4()">My Tasks</li>               
            </ul>

        </div>
        <div class="div-2">
            <iframe id="frame_1" class="frame" src="./cus_my_acc_1.php"></iframe>
            <!--<div class="circle"><a href="#"><i class='bx bxs-camera-plus'></i></a></div>
            <div class="grid-container">
                <div class="grid-item">Name</div>
                <div class="grid-item">Telephone</div>
                <div class="grid-item"><input id="label" type="text"></div>
                  
                <div class="grid-item"><input id="label" type="text"></div>
                <div class="grid-item">Address</div>
                <div class="grid-item">Email</div>
                <div class="grid-item"><input id="label" type="text"></div>  
                
                <div class="grid-item"><input id="label" type="email"></div>
                <div class="grid-item-1"><input id="label" type="submit" value="Update"></div>
        
                  
            </div>-->
            
        </div>
    </section>


<!--==================================Footer====================================-->



    <section class="footer">
        <div id="item"><a href="#">Terms and Conditions</a></div>
        <div id="item"><a href="#">Help</a></div>
        <div id="item"><a href="#">CS2001</a></div>


    </section>



</body>



