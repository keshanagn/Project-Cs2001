<!DOCTYPE html>
<head>
    <link rel="stylesheet" href="./cus_tasks.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script src="./cus_tasks/cus_tasks.js"></script>
</head>
<body>
    <div class="nav-bar">
        <div id="searchbox">
            <!-- <ul>
                <li><input type="search" placeholder="Search Contacts..."></li>
                <li><i class='bx bx-search'>Search</i></li>
            </ul> -->
        </div>
        <div id="list">
            <ul>
                <li onclick="openform()">Add</li>
                <!-- <li>Delete</li>
                <li>Update</li> -->
            </ul>
        </div>

    </div>
    <div class="form">
        <iframe id="task_table" src="./cus_tasks/task_details.php"></iframe>
        <!-- <form>
            <div class="grid-container">
                
                <div class="grid-item">Name</div>
                <div class="grid-item">Business</div>
                <div class="grid-item">Telephone</div>
                <div class="grid-item">Address</div>
                <div class="grid-item">1</div>
                
            </div>
        </form> -->
    </div>

</body>