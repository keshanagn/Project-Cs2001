<!DOCTYPE html>
<head>
    <link rel="stylesheet" href="./cus_my_acc.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <form action="./action.php" id="userform">
        <div class="div-2">
            <div class="circle"><a href="#"><i class='bx bxs-camera-plus'></i></a></div>
            <div class="grid-container">
                <div class="grid-item">Name</div>
                <div class="grid-item">Telephone</div>
                <div class="grid-item"><input id="label" type="text"></div>
                  
                <div class="grid-item"><input id="label" type="text"></div>
                <div class="grid-item">Address</div>
                <div class="grid-item">Email</div>
                <div class="grid-item"><input id="label" type="text"></div>  
                
                <div class="grid-item"><input id="label" type="email"></div>
                <div class="grid-item-1"><input id="label" type="submit" value="Update"></div>
        
                  
            </div>
            
        </div>
    </form>
</body>