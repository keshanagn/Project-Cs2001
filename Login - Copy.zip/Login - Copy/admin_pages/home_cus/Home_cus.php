

<?php

include '../../connection.php';
include '../../function.php';

if (!isLoggedIn()) {
    $_SESSION['msg'] = "You must log in first";
    header('location: ../../Sign In/login.php');
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Template</title>
    <link rel="stylesheet" href="./home.css">
</head>
<body>
    
    
<!--================================Header====================================-->



    <header class="head-1">
        <div id="sec-1">
            <a href="#">
                <img src="./mushroom.png" style="width: 50px; height: 50px;">
                <p style="font-family: Arial, Helvetica, sans-serif; font-size: 40px; color: rgb(106, 98, 98);">CRM</p>
            </a>
        </div>
        <div id="sec-2">
            <ul id="ul-1">
                <li><a href="#">Help</a></li>
                <li><a href="#">Contact Us</a></li>
                <!-- <li><a href="../Sign up/register.php">Sign up</a></li> -->


                <!-- <?php if (isset($_SESSION['user'])) : ?>
                    <p><strong><?php echo $_SESSION['user']['username']; ?></strong></p>
                    <p><a href="Home_cus.php?logout='1'">Sign Out</a></p>
                    <small>
                        <p><a href="customer_1.php?logout='1'">Sign Out</a></p>
                
                    </small>

                <?php endif ?> -->
                <!-- <li><a href="../Sign In/login.php">Sign in</a></li> -->
                
            </ul>
        </div>
    </header>

    <!--=================================Sign-Out==================================-->


    <section class="sign-out">   
        <!-- <p><a href="customer_1.php?logout='1'">Sign Out</a></p>   -->
        <?php if (isset($_SESSION['user'])) : ?>
            <p><a href="Home_cus.php?logout='1'">Sign Out</a></p>
            <p id="user">user: <strong><?php echo $_SESSION['user']['username']; ?></strong></p>
            
            <!-- <small>
                <p><a href="Home_cus.php?logout='1'">Sign Out</a></p> 
            </small> -->

        <?php endif ?>
    </section>


    <!--=================================Body Part==================================-->


    <section class="middle">




        
        
        <!--Enter the body part code here-->
        <!--Enter the body part code here-->
        <!--Enter the body part code here-->
        <!--Enter the body part code here-->









    </section>


    <!--==================================Footer====================================-->



    <section class="footer">
        <div id="item"><a href="#">Terms and Conditions</a></div>
        <div id="item"><a href="#">Help</a></div>
        <div id="item"><a href="#">CS2001</a></div>


    </section>

</body>
</html>